package com.reso.ai

import android.net.Uri
import androidx.work.Data
import androidx.work.workDataOf

data class VideoInfo(
    val uri: Uri, val name: String, val width: Int, val height: Int, val rotation: Int,
    val durationUs: Long, val fps: Float, val hasAudio: Boolean
) {
    val displayAspect get() = if (rotation == 90 || rotation == 270) height.toFloat() / width else width.toFloat() / height
}

data class EnhanceSettings(
    val targetShortSide: Int = 1080,   // 720 / 1080 / 1440 / 2160 (short side, so portrait works too)
    val doubleFps: Boolean = false,    // 2x frame rate via frame blending (NOT AI)
    val bitrateMbps: Int = 0,          // 0 = auto
    val useAi: Boolean = true,         // only effective if a model is installed
    val anime: Boolean = false,        // selects the anime model slot
    val aiStrength: Float = 0.85f,     // opacity of AI output over plain resize
    val sharpen: Float = 0.15f,        // conventional unsharp amount (NOT AI)
    val denoise: Boolean = false,      // only effective if a denoise model is installed
    val previewSeconds: Int = 0        // >0 = process only the first N seconds
) {
    fun toData(uri: Uri): Data = workDataOf(
        "uri" to uri.toString(), "short" to targetShortSide, "dbl" to doubleFps, "mbps" to bitrateMbps,
        "ai" to useAi, "anime" to anime, "str" to aiStrength, "sharp" to sharpen, "dn" to denoise, "prev" to previewSeconds
    )
    companion object {
        fun from(d: Data) = EnhanceSettings(
            d.getInt("short", 1080), d.getBoolean("dbl", false), d.getInt("mbps", 0), d.getBoolean("ai", true),
            d.getBoolean("anime", false), d.getFloat("str", 0.85f), d.getFloat("sharp", 0.15f),
            d.getBoolean("dn", false), d.getInt("prev", 0)
        )
    }
}
