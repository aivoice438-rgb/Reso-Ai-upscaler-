package com.reso.ai

import android.content.Context
import android.media.*
import android.net.Uri
import android.provider.OpenableColumns
import kotlin.math.max
import kotlin.math.roundToInt

object Probe {
    fun read(ctx: Context, uri: Uri): VideoInfo {
        val ex = MediaExtractor()
        ex.setDataSource(ctx, uri, null)
        try {
            var v: MediaFormat? = null
            var audio = false
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                val m = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (m.startsWith("video/") && v == null) v = f
                if (m.startsWith("audio/")) audio = true
            }
            val f = v ?: error("No video track found")
            if (f.containsKey(MediaFormat.KEY_COLOR_TRANSFER) && f.getInteger(MediaFormat.KEY_COLOR_TRANSFER).let { it == 6 || it == 7 })
                error("HDR (PQ/HLG) video is not supported yet — tone-mapping is not implemented.")
            val dur = if (f.containsKey(MediaFormat.KEY_DURATION)) f.getLong(MediaFormat.KEY_DURATION) else {
                val r = MediaMetadataRetriever().apply { setDataSource(ctx, uri) }
                (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L) * 1000
            }
            val fps = try { f.getInteger(MediaFormat.KEY_FRAME_RATE).toFloat() } catch (_: Exception) {
                try { f.getFloat(MediaFormat.KEY_FRAME_RATE) } catch (_: Exception) { 30f } }
            val name = ctx.contentResolver.query(uri, null, null, null, null)?.use {
                if (it.moveToFirst()) it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
            } ?: "video"
            return VideoInfo(uri, name.substringBeforeLast('.'), f.getInteger(MediaFormat.KEY_WIDTH), f.getInteger(MediaFormat.KEY_HEIGHT),
                if (f.containsKey(MediaFormat.KEY_ROTATION)) f.getInteger(MediaFormat.KEY_ROTATION) else 0, dur, fps, audio)
        } finally { ex.release() }
    }

    /** Output frame size; "1080p" means short side 1080 so portrait clips work too. */
    fun outputDims(i: VideoInfo, shortSide: Int): Pair<Int, Int> {
        val f = shortSide.toFloat() / minOf(i.width, i.height)
        return Pair((i.width * f).roundToInt() and 1.inv(), (i.height * f).roundToInt() and 1.inv())
    }

    /** Returns a hardware-encodable mime for this size, or null if the device cannot encode it. */
    fun pickMime(w: Int, h: Int): String? {
        val order = listOf("video/hevc", "video/avc").let { if (max(w, h) > 1920) it else it.reversed() }
        val infos = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos
        for (m in order) {
            val ok = infos.any { ci ->
                ci.isEncoder && ci.supportedTypes.contains(m) &&
                    try { ci.getCapabilitiesForType(m).videoCapabilities.isSizeSupported(w, h) } catch (_: Exception) { false }
            }
            if (ok) return m
        }
        return null
    }
}
