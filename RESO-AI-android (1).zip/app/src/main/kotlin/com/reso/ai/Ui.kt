package com.reso.ai

import android.view.TextureView
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.GenericShape
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.work.WorkInfo
import kotlinx.coroutines.delay

val Blue = Color(0xFF3D8BFF); val Bg = Color(0xFF0B0E14); val Card = Color(0xFF141A24); val Dim = Color(0xFF8A94A6)

@Composable fun ResoTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(primary = Blue, background = Bg, surface = Card, onBackground = Color.White, onSurface = Color.White),
    content = { Surface(color = Bg, modifier = Modifier.fillMaxSize(), content = content) })

@Composable fun App(vm: AppVm, onGallery: () -> Unit, onFiles: () -> Unit, onModel: (ModelStore.Slot) -> Unit) {
    Box(Modifier.fillMaxSize().systemBarsPadding()) {
        AnimatedContent(vm.screen, transitionSpec = { fadeIn(tween(250)) togetherWith fadeOut(tween(150)) }, label = "nav") { s ->
            when (s) {
                AppVm.Screen.HOME -> Home(vm, onGallery, onFiles)
                AppVm.Screen.CONFIG -> Config(vm)
                AppVm.Screen.RUN -> Run(vm)
                AppVm.Screen.COMPARE -> Compare(vm)
                AppVm.Screen.MODELS -> Models(vm, onModel)
            }
        }
        vm.message?.let { m ->
            AlertDialog(onDismissRequest = { vm.message = null }, confirmButton = { TextButton({ vm.message = null }) { Text("OK") } }, text = { Text(m) })
        }
    }
}

@Composable fun Page(content: @Composable ColumnScope.() -> Unit) =
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp), content = content)

@Composable fun Panel(content: @Composable ColumnScope.() -> Unit) =
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Card).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = content)

@Composable fun Home(vm: AppVm, onGallery: () -> Unit, onFiles: () -> Unit) = Page {
    Spacer(Modifier.height(24.dp))
    Text("RESO AI", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Blue)
    Text("Video Enhancer", fontSize = 18.sp, color = Dim)
    Spacer(Modifier.height(12.dp))
    Button(onGallery, Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(14.dp)) { Text("Pick from gallery") }
    OutlinedButton(onFiles, Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(14.dp)) { Text("Browse files") }
    OutlinedButton({ vm.screen = AppVm.Screen.MODELS }, Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(14.dp)) { Text("AI models") }
    Panel {
        Text("Honest by design", fontWeight = FontWeight.SemiBold)
        Text("AI steps run only when a model file is installed. Without one, RESO AI uses conventional resizing and says so. " +
            "Progress and ETA come from real decoded frames. Frame-rate doubling is blending, not AI.", color = Dim, fontSize = 13.sp)
    }
}

@Composable fun Models(vm: AppVm, onModel: (ModelStore.Slot) -> Unit) = Page {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(vm.message) { tick++ }
    TextButton({ vm.screen = AppVm.Screen.HOME }) { Text("← Back") }
    Text("AI models", fontSize = 26.sp, fontWeight = FontWeight.Bold)
    Text("Models are not bundled. Import TFLite files you are licensed to use (e.g. Real-ESRGAN, BSD-3). " +
        "Input must be float32 [1,N,N,3] in 0..1; output ×4 (or same size for the denoiser).", color = Dim, fontSize = 13.sp)
    ModelStore.Slot.values().forEach { slot ->
        key(tick) {
            Panel {
                Text(slot.title, fontWeight = FontWeight.SemiBold)
                Text(if (ModelStore.installed(ctx, slot)) "✓ Installed" else "Not installed", color = if (ModelStore.installed(ctx, slot)) Blue else Dim)
                OutlinedButton({ onModel(slot) }) { Text("Import .tflite") }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun Config(vm: AppVm) = Page {
    val ctx = LocalContext.current
    val info = vm.info ?: return@Page
    val s = vm.settings
    val slot = if (s.anime) ModelStore.Slot.ANIME else ModelStore.Slot.GENERAL
    val aiAvail = ModelStore.installed(ctx, slot)
    val dnAvail = ModelStore.installed(ctx, ModelStore.Slot.DENOISE)
    val ai = s.useAi && aiAvail
    TextButton({ vm.screen = AppVm.Screen.HOME }) { Text("← Back") }
    Panel {
        Text(info.name, fontWeight = FontWeight.SemiBold, maxLines = 1)
        Text("${info.width}×${info.height} · ${"%.1f".format(info.fps)} fps · ${info.durationUs / 1_000_000}s" + if (info.rotation != 0) " · rot ${info.rotation}°" else "", color = Dim, fontSize = 13.sp)
    }
    Panel {
        Text("Output resolution", fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(720 to "720p", 1080 to "1080p", 1440 to "1440p", 2160 to "4K").forEach { (v, label) ->
                val (w, h) = remember(v, info) { Probe.outputDims(info, v) }
                val ok = remember(v, info) { Probe.pickMime(w, h) != null }
                FilterChip(s.targetShortSide == v, { vm.settings = s.copy(targetShortSide = v) }, { Text(label) }, enabled = ok)
            }
        }
        if (s.targetShortSide == 2160 && ai) Text("On-device AI at 4K is very slow. Run the 3-second preview to measure your phone's real speed first.", color = Dim, fontSize = 12.sp)
        Text("Bitrate", fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(0 to "Auto", 8 to "8", 16 to "16", 32 to "32", 64 to "64").forEach { (v, l) ->
                FilterChip(s.bitrateMbps == v, { vm.settings = s.copy(bitrateMbps = v) }, { Text(l) })
            }
        }
    }
    Panel {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text("AI super-resolution", fontWeight = FontWeight.SemiBold)
                Text(if (aiAvail) "Model installed" else "No ${slot.file} installed — conventional resize will be used", color = Dim, fontSize = 12.sp) }
            Switch(s.useAi && aiAvail, { vm.settings = s.copy(useAi = it) }, enabled = aiAvail)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Anime model", Modifier.weight(1f)); Switch(s.anime, { vm.settings = s.copy(anime = it) })
        }
        Text("AI strength ${(s.aiStrength * 100).toInt()}% (lower = closer to the original look)", fontSize = 13.sp)
        Slider(s.aiStrength, { vm.settings = s.copy(aiStrength = it) }, enabled = ai)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text("AI denoise", fontWeight = FontWeight.SemiBold)
                if (!dnAvail) Text("No denoise model installed", color = Dim, fontSize = 12.sp) }
            Switch(s.denoise && dnAvail, { vm.settings = s.copy(denoise = it) }, enabled = dnAvail)
        }
        Text("Conventional sharpen ${(s.sharpen * 100).toInt()}% (not AI, max 60%)", fontSize = 13.sp)
        Slider(s.sharpen, { vm.settings = s.copy(sharpen = it) }, valueRange = 0f..0.6f)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text("2× frame rate (blending)", fontWeight = FontWeight.SemiBold)
                Text("Not motion-compensated, not AI. Can ghost on fast motion.", color = Dim, fontSize = 12.sp) }
            Switch(s.doubleFps, { vm.settings = s.copy(doubleFps = it) })
        }
    }
    Panel {
        Text("What will actually run", fontWeight = FontWeight.SemiBold)
        Text(if (ai) "• Upscale: AI model (${slot.file}), tiled" else "• Upscale: conventional bilinear resize (no AI)", fontSize = 13.sp, color = Dim)
        Text(if (s.denoise && dnAvail) "• Denoise: AI model" else "• Denoise: none", fontSize = 13.sp, color = Dim)
        Text(if (s.sharpen > 0f) "• Sharpen: conventional unsharp (not AI)" else "• Sharpen: off", fontSize = 13.sp, color = Dim)
        Text(if (s.doubleFps) "• Frames: 2× blending (not AI)" else "• Frames: unchanged", fontSize = 13.sp, color = Dim)
    }
    OutlinedButton({ vm.start(true) }, Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(14.dp)) { Text("Preview first 3 seconds") }
    Button({ vm.start(false) }, Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(14.dp)) { Text("Enhance & export") }
}

@Composable fun Run(vm: AppVm) {
    val id = vm.workId ?: return
    val wi by vm.wm.getWorkInfoByIdFlow(id).collectAsState(null)
    val st = wi?.state
    LaunchedEffect(st) {
        when (st) {
            WorkInfo.State.SUCCEEDED -> wi?.outputData?.let {
                vm.resultUri = android.net.Uri.parse(it.getString("out")); vm.resultNote = it.getString("note") ?: ""
                vm.resultWarn = it.getString("warn") ?: ""; vm.resultSecs = it.getFloat("secs", 0f); vm.resultClip = it.getFloat("clip", 0f)
                vm.screen = AppVm.Screen.COMPARE }
            WorkInfo.State.FAILED -> { vm.message = wi?.outputData?.getString("error") ?: "Processing failed"; vm.screen = AppVm.Screen.CONFIG }
            WorkInfo.State.CANCELLED -> vm.screen = AppVm.Screen.CONFIG
            else -> {}
        }
    }
    val p = wi?.progress?.getFloat("p", -1f) ?: -1f
    val eta = wi?.progress?.getLong("eta", -1L) ?: -1L
    Column(Modifier.fillMaxSize().padding(28.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(if (vm.runIsPreview) "Rendering 3-second preview" else "Enhancing", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp))
        if (p < 0f) LinearProgressIndicator(Modifier.fillMaxWidth()) else LinearProgressIndicator({ p }, Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        Text(if (p < 0f) "Starting…" else "${(p * 100).toInt()}%  ·  " + (if (eta >= 0) "about ${eta / 60}m ${eta % 60}s left" else "estimating…"), color = Dim)
        Text("Keep the app open; a notification shows progress.", color = Dim, fontSize = 12.sp)
        Spacer(Modifier.height(24.dp))
        OutlinedButton({ vm.cancel() }) { Text("Cancel") }
    }
}

@Composable fun Compare(vm: AppVm) {
    val ctx = LocalContext.current
    val info = vm.info ?: return
    val enhanced = vm.resultUri ?: return
    val clipMs = if (vm.runIsPreview) 3000L else Long.MAX_VALUE
    val a = remember { ExoPlayer.Builder(ctx).build().apply {
        setMediaItem(MediaItem.Builder().setUri(info.uri).setClippingConfiguration(MediaItem.ClippingConfiguration.Builder().apply { if (clipMs != Long.MAX_VALUE) setEndPositionMs(clipMs) }.build()).build())
        repeatMode = Player.REPEAT_MODE_ALL; volume = 0f; prepare() } }
    val b = remember { ExoPlayer.Builder(ctx).build().apply { setMediaItem(MediaItem.fromUri(enhanced)); repeatMode = Player.REPEAT_MODE_ALL; prepare() } }
    DisposableEffect(Unit) { onDispose { a.release(); b.release() } }
    var split by remember { mutableFloatStateOf(0.5f) }
    var playing by remember { mutableStateOf(false) }
    LaunchedEffect(playing) { a.playWhenReady = playing; b.playWhenReady = playing }
    LaunchedEffect(Unit) { while (true) { if (kotlin.math.abs(a.currentPosition - b.currentPosition) > 80) a.seekTo(b.currentPosition); delay(400) } }

    Page {
        Text(if (vm.runIsPreview) "Preview" else "Done — saved to Movies/RESO AI", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Box(Modifier.fillMaxWidth().aspectRatio(info.displayAspect).clip(RoundedCornerShape(12.dp)).background(Color.Black)) {
            AndroidView({ TextureView(it).also { tv -> b.setVideoTextureView(tv) } }, Modifier.fillMaxSize())
            AndroidView({ TextureView(it).also { tv -> a.setVideoTextureView(tv) } },
                Modifier.fillMaxSize().clip(GenericShape { size, _ -> addRect(Rect(0f, 0f, size.width * split, size.height)) }))
            BoxWithConstraints(Modifier.fillMaxSize().pointerInput(Unit) {
                detectHorizontalDragGestures { c, _ -> split = (c.position.x / size.width).coerceIn(0.02f, 0.98f) }
            }) {
                Box(Modifier.offset(x = maxWidth * split - 1.dp).width(2.dp).fillMaxHeight().background(Blue))
                Text("ORIGINAL", Modifier.padding(8.dp), fontSize = 11.sp)
                Text("ENHANCED", Modifier.align(Alignment.TopEnd).padding(8.dp), fontSize = 11.sp, color = Blue)
            }
        }
        Text("Drag the line to compare.", color = Dim, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button({ playing = !playing }) { Text(if (playing) "Pause" else "Play") }
            if (vm.runIsPreview) {
                OutlinedButton({ vm.screen = AppVm.Screen.CONFIG }) { Text("Adjust") }
                Button({ vm.start(false) }) { Text("Export full") }
            } else OutlinedButton({ vm.screen = AppVm.Screen.HOME }) { Text("New video") }
        }
        if (vm.runIsPreview) {
            val est = if (vm.resultClip > 0) vm.resultSecs / vm.resultClip * (info.durationUs / 1e6f) else 0f
            Text("Measured on this phone: ${"%.1f".format(vm.resultSecs)}s for ${"%.1f".format(vm.resultClip)}s of video → full video ≈ ${(est / 60).toInt()}m ${(est % 60).toInt()}s (extrapolated).", color = Dim, fontSize = 12.sp)
        }
        Panel { Text("What ran", fontWeight = FontWeight.SemiBold); Text(vm.resultNote, color = Dim, fontSize = 12.sp)
            if (vm.resultWarn.isNotEmpty()) Text(vm.resultWarn, color = Color(0xFFFFB84D), fontSize = 12.sp) }
    }
}
