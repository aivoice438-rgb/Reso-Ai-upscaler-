package com.reso.ai

import android.content.Context
import android.graphics.*
import java.io.Closeable

/** Per-frame enhancement. Reuses its output bitmap; callers must copy if they keep it. */
class FrameEnhancer(ctx: Context, private val s: EnhanceSettings, srcW: Int, srcH: Int, val outW: Int, val outH: Int) : Closeable {
    private val srSlot = if (s.anime) ModelStore.Slot.ANIME else ModelStore.Slot.GENERAL
    private val sr: TileModel? = if (s.useAi && ModelStore.installed(ctx, srSlot)) TileModel(ModelStore.file(ctx, srSlot), srSlot.scale) else null
    private val dn: TileModel? = if (s.denoise && ModelStore.installed(ctx, ModelStore.Slot.DENOISE))
        TileModel(ModelStore.file(ctx, ModelStore.Slot.DENOISE), 1) else null
    private val plain = Paint(Paint.FILTER_BITMAP_FLAG)
    private var denBmp: Bitmap? = null
    val out: Bitmap = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)

    /** Honest description of what actually runs, shown to the user after export. */
    val describe: String = buildString {
        append(if (sr != null) "AI super-resolution (${if (s.anime) "anime" else "general"} model, ×${sr.scale}, tiled, ${if (sr.usesGpu) "GPU" else "CPU"}, strength ${(s.aiStrength * 100).toInt()}%)"
               else "Conventional bilinear resize (no AI model used)")
        append(if (dn != null) "; AI denoise" else "; no denoise")
        append(if (s.sharpen > 0f) "; conventional unsharp ${(s.sharpen * 100).toInt()}% (not AI)" else "; no sharpening")
        append(if (s.doubleFps) "; 2× frame blending (not motion-compensated, not AI)" else "; source frame rate")
    }

    fun process(src: Bitmap, check: () -> Unit): Bitmap {
        var input = src
        dn?.let {
            val d = denBmp ?: Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888).also { b -> denBmp = b }
            it.run(src, d, 255, check); input = d
        }
        Canvas(out).drawBitmap(input, null, Rect(0, 0, outW, outH), plain)
        sr?.run(input, out, (s.aiStrength * 255).toInt().coerceIn(0, 255), check)
        if (s.sharpen > 0f) unsharp(out, s.sharpen.coerceAtMost(0.6f))
        return out
    }

    private fun unsharp(b: Bitmap, amt: Float) {
        val w = b.width; val h = b.height
        val px = IntArray(w * h); b.getPixels(px, 0, w, 0, 0, w, h)
        val res = px.copyOf()
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            var r = 0; var g = 0; var bl = 0
            for (dy in -1..1) for (dx in -1..1) {
                val p = px[i + dy * w + dx]
                r += (p shr 16) and 255; g += (p shr 8) and 255; bl += p and 255
            }
            val c = px[i]
            val cr = (c shr 16) and 255; val cg = (c shr 8) and 255; val cb = c and 255
            val nr = (cr + amt * (cr - r / 9f)).toInt().coerceIn(0, 255)
            val ng = (cg + amt * (cg - g / 9f)).toInt().coerceIn(0, 255)
            val nb = (cb + amt * (cb - bl / 9f)).toInt().coerceIn(0, 255)
            res[i] = (255 shl 24) or (nr shl 16) or (ng shl 8) or nb
        }
        b.setPixels(res, 0, w, 0, 0, w, h)
    }

    override fun close() { sr?.close(); dn?.close(); denBmp?.recycle(); out.recycle() }
}
