package com.reso.ai

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

class AppVm(private val app: Application) : AndroidViewModel(app) {
    enum class Screen { HOME, CONFIG, RUN, COMPARE, MODELS }
    var screen by mutableStateOf(Screen.HOME)
    var info by mutableStateOf<VideoInfo?>(null)
    var settings by mutableStateOf(EnhanceSettings())
    var workId by mutableStateOf<UUID?>(null)
    var runIsPreview by mutableStateOf(false)
    var resultUri by mutableStateOf<Uri?>(null)
    var resultNote by mutableStateOf("")
    var resultWarn by mutableStateOf("")
    var resultSecs by mutableStateOf(0f)
    var resultClip by mutableStateOf(0f)
    var message by mutableStateOf<String?>(null)
    val wm: WorkManager = WorkManager.getInstance(app)

    fun load(uri: Uri) = viewModelScope.launch {
        try { info = withContext(Dispatchers.IO) { Probe.read(app, uri) }; screen = Screen.CONFIG }
        catch (e: Throwable) { message = e.message ?: "Could not open this video" }
    }

    fun start(preview: Boolean) {
        val i = info ?: return
        runIsPreview = preview
        val s = settings.copy(previewSeconds = if (preview) 3 else 0)
        val req = OneTimeWorkRequestBuilder<EnhanceWorker>().setInputData(s.toData(i.uri)).build()
        wm.enqueue(req); workId = req.id; screen = Screen.RUN
    }

    fun cancel() { workId?.let { wm.cancelWorkById(it) } }

    fun importModel(slot: ModelStore.Slot, uri: Uri) = viewModelScope.launch {
        message = try { withContext(Dispatchers.IO) { ModelStore.import(app, slot, uri) } }
        catch (e: Throwable) { "Model rejected: ${e.message}" }
    }
}
