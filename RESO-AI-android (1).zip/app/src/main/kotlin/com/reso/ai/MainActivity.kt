package com.reso.ai

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.*

class MainActivity : ComponentActivity() {
    private val vm: AppVm by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ResoTheme {
                var pendingSlot by remember { mutableStateOf<ModelStore.Slot?>(null) }
                val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
                LaunchedEffect(Unit) { if (Build.VERSION.SDK_INT >= 33) notif.launch(Manifest.permission.POST_NOTIFICATIONS) }
                val gallery = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { it?.let(vm::load) }
                val files = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
                    u?.let { runCatching { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) }; vm.load(it) }
                }
                val model = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
                    val slot = pendingSlot; if (u != null && slot != null) vm.importModel(slot, u)
                }
                App(vm,
                    onGallery = { gallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) },
                    onFiles = { files.launch(arrayOf("video/*")) },
                    onModel = { pendingSlot = it; model.launch(arrayOf("*/*")) })
            }
        }
    }
}
