package com.reso.ai

import android.content.Context
import android.graphics.*
import android.media.*
import android.os.Handler
import android.os.HandlerThread
import java.io.File
import java.nio.ByteBuffer
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Streaming pipeline for ONE time segment: MediaCodec decode -> ImageReader (YUV) -> Bitmap -> FrameEnhancer -> MediaCodec encode.
 * Only a handful of frames are alive at once, so memory stays flat regardless of video length. Video-only output;
 * audio is copied from the source in [Finalizer].
 */
class SegmentProcessor(
    private val ctx: Context, private val info: VideoInfo, private val s: EnhanceSettings,
    private val enh: FrameEnhancer, private val mime: String
) {
    private val outW = enh.outW; private val outH = enh.outH
    private val outFps = (info.fps * if (s.doubleFps) 2 else 1)

    private fun bitrate(): Int {
        if (s.bitrateMbps > 0) return s.bitrateMbps * 1_000_000
        val k = if (mime == "video/hevc") 0.09 else 0.12
        return min(80_000_000.0, outW.toDouble() * outH * outFps * k).toInt()
    }

    fun run(startUs: Long, endUs: Long, outFile: File, check: () -> Unit, onPts: (Long) -> Unit): Boolean {
        val ex = MediaExtractor(); ex.setDataSource(ctx, info.uri, null)
        val vt = (0 until ex.trackCount).first { ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)!!.startsWith("video/") }
        ex.selectTrack(vt)
        val fmt = ex.getTrackFormat(vt)
        ex.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
        val w = fmt.getInteger(MediaFormat.KEY_WIDTH); val h = fmt.getInteger(MediaFormat.KEY_HEIGHT)

        val ht = HandlerThread("reso-reader").also { it.start() }
        val reader = ImageReader.newInstance(w, h, ImageFormat.YUV_420_888, 3)
        val avail = LinkedBlockingQueue<Boolean>()
        reader.setOnImageAvailableListener({ avail.offer(true) }, Handler(ht.looper))
        val dec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
        val enc = MediaCodec.createEncoderByType(mime)
        val mux = MediaMuxer(outFile.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var muxTrack = -1; var muxStarted = false

        val src = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val srcPx = IntArray(w * h)
        val outPx = IntArray(outW * outH)
        val prev = if (s.doubleFps) Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888) else null
        val mid = if (s.doubleFps) Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888) else null
        val half = Paint().apply { alpha = 128 }
        var prevPts = -1L
        val encInfo = MediaCodec.BufferInfo()

        fun drainEnc(untilEos: Boolean): Boolean {
            while (true) {
                if (untilEos) check()
                val i = enc.dequeueOutputBuffer(encInfo, if (untilEos) 10_000 else 0)
                when {
                    i == MediaCodec.INFO_TRY_AGAIN_LATER -> { if (!untilEos) return false }
                    i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        muxTrack = mux.addTrack(enc.outputFormat); mux.start(); muxStarted = true
                    }
                    i >= 0 -> {
                        val b = enc.getOutputBuffer(i)!!
                        if (encInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) encInfo.size = 0
                        if (encInfo.size > 0 && muxStarted) mux.writeSampleData(muxTrack, b, encInfo)
                        enc.releaseOutputBuffer(i, false)
                        if (encInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return true
                    }
                }
            }
        }

        fun feed(bmp: Bitmap, ptsUs: Long) {
            var idx: Int
            while (true) { check(); drainEnc(false); idx = enc.dequeueInputBuffer(10_000); if (idx >= 0) break }
            fillImage(enc.getInputImage(idx)!!, bmp, outPx)
            enc.queueInputBuffer(idx, 0, outW * outH * 3 / 2, ptsUs, 0)
        }

        var lastRel = 0L
        try {
            val ef = MediaFormat.createVideoFormat(mime, outW, outH).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
                setInteger(MediaFormat.KEY_BIT_RATE, bitrate())
                setInteger(MediaFormat.KEY_FRAME_RATE, outFps.roundToInt())
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
                setInteger(MediaFormat.KEY_COLOR_STANDARD, MediaFormat.COLOR_STANDARD_BT709)
                setInteger(MediaFormat.KEY_COLOR_RANGE, MediaFormat.COLOR_RANGE_LIMITED)
            }
            enc.configure(ef, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE); enc.start()
            dec.configure(fmt, reader.surface, null, 0); dec.start()

            val di = MediaCodec.BufferInfo()
            var inDone = false; var decDone = false
            while (!decDone) {
                check()
                if (!inDone) {
                    val ii = dec.dequeueInputBuffer(5_000)
                    if (ii >= 0) {
                        val n = ex.readSampleData(dec.getInputBuffer(ii)!!, 0)
                        if (n < 0 || ex.sampleTime > endUs + 500_000) {
                            dec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true
                        } else { dec.queueInputBuffer(ii, 0, n, ex.sampleTime, 0); ex.advance() }
                    }
                }
                val oi = dec.dequeueOutputBuffer(di, 5_000)
                if (oi >= 0) {
                    val pts = di.presentationTimeUs
                    val use = di.size > 0 && pts >= startUs && pts < endUs
                    dec.releaseOutputBuffer(oi, use)
                    if (use) {
                        if (avail.poll(3, TimeUnit.SECONDS) == null) error("Decoder produced no frame (device/codec issue)")
                        val img = reader.acquireNextImage() ?: error("No image from decoder")
                        imageToBitmap(img, src, srcPx); img.close()
                        val out = enh.process(src, check)
                        val rel = pts - startUs
                        if (prev != null && mid != null && prevPts >= 0) {
                            val c = Canvas(mid); c.drawBitmap(prev, 0f, 0f, null); c.drawBitmap(out, 0f, 0f, half)
                            feed(mid, (prevPts + rel) / 2)
                        }
                        feed(out, rel)
                        prev?.let { Canvas(it).drawBitmap(out, 0f, 0f, null) }
                        prevPts = rel; lastRel = rel
                        onPts(pts)
                    }
                    if (di.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) decDone = true
                }
            }
            var idx: Int
            while (true) { check(); drainEnc(false); idx = enc.dequeueInputBuffer(10_000); if (idx >= 0) break }
            enc.queueInputBuffer(idx, 0, 0, lastRel, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
            drainEnc(true)
            return muxStarted
        } finally {
            runCatching { dec.stop() }; runCatching { dec.release() }
            runCatching { enc.stop() }; runCatching { enc.release() }
            if (muxStarted) runCatching { mux.stop() }
            runCatching { mux.release() }
            runCatching { ex.release() }; reader.close(); ht.quitSafely()
            src.recycle(); prev?.recycle(); mid?.recycle()
        }
    }

    // BT.709 limited range. SDR only (HDR is rejected in Probe).
    private fun imageToBitmap(img: Image, bmp: Bitmap, px: IntArray) {
        val w = img.width; val h = img.height
        val yP = img.planes[0]; val uP = img.planes[1]; val vP = img.planes[2]
        val yb = yP.buffer; val ub = uP.buffer; val vb = vP.buffer
        for (y in 0 until h) {
            val yo = y * yP.rowStride; val uo = (y shr 1) * uP.rowStride; val vo = (y shr 1) * vP.rowStride
            for (x in 0 until w) {
                val yy = 1.1644f * ((yb.get(yo + x).toInt() and 255) - 16)
                val u = (ub.get(uo + (x shr 1) * uP.pixelStride).toInt() and 255) - 128
                val v = (vb.get(vo + (x shr 1) * vP.pixelStride).toInt() and 255) - 128
                val r = (yy + 1.7927f * v).toInt().coerceIn(0, 255)
                val g = (yy - 0.2132f * u - 0.5329f * v).toInt().coerceIn(0, 255)
                val b = (yy + 2.1124f * u).toInt().coerceIn(0, 255)
                px[y * w + x] = (255 shl 24) or (r shl 16) or (g shl 8) or b
            }
        }
        bmp.setPixels(px, 0, w, 0, 0, w, h)
    }

    private fun fillImage(img: Image, bmp: Bitmap, px: IntArray) {
        val w = bmp.width; val h = bmp.height
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val yP = img.planes[0]; val uP = img.planes[1]; val vP = img.planes[2]
        val yb = yP.buffer; val ub = uP.buffer; val vb = vP.buffer
        for (y in 0 until h) {
            val yo = y * yP.rowStride
            for (x in 0 until w) {
                val p = px[y * w + x]
                val r = (p shr 16) and 255; val g = (p shr 8) and 255; val b = p and 255
                yb.put(yo + x, (((47 * r + 157 * g + 16 * b) shr 8) + 16).toByte())
                if ((y and 1) == 0 && (x and 1) == 0) {
                    val uo = (y shr 1) * uP.rowStride + (x shr 1) * uP.pixelStride
                    val vo = (y shr 1) * vP.rowStride + (x shr 1) * vP.pixelStride
                    ub.put(uo, (((-26 * r - 87 * g + 112 * b) shr 8) + 128).toByte())
                    vb.put(vo, (((112 * r - 102 * g - 10 * b) shr 8) + 128).toByte())
                }
            }
        }
    }
}

/** Joins the per-segment video files (no re-encode) and copies the original audio track. Returns a warning or null. */
object Finalizer {
    fun concat(ctx: Context, info: VideoInfo, segs: List<Pair<File, Long>>, out: File, endUs: Long): String? {
        val mux = MediaMuxer(out.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        mux.setOrientationHint(info.rotation)
        fun vidIdx(e: MediaExtractor) = (0 until e.trackCount).first { e.getTrackFormat(it).getString(MediaFormat.KEY_MIME)!!.startsWith("video/") }
        val first = MediaExtractor().apply { setDataSource(segs[0].first.path) }
        val vTrack = mux.addTrack(first.getTrackFormat(vidIdx(first))); first.release()
        var warn: String? = null
        var aEx: MediaExtractor? = null; var aTrack = -1
        if (info.hasAudio) {
            try {
                aEx = MediaExtractor().apply { setDataSource(ctx, info.uri, null) }
                val ai = (0 until aEx.trackCount).first { aEx.getTrackFormat(it).getString(MediaFormat.KEY_MIME)!!.startsWith("audio/") }
                aEx.selectTrack(ai); aTrack = mux.addTrack(aEx.getTrackFormat(ai))
            } catch (e: Exception) { warn = "Audio could not be copied (${e.message}); exported without sound."; aTrack = -1 }
        }
        mux.start()
        val buf = ByteBuffer.allocateDirect(8 shl 20); val bi = MediaCodec.BufferInfo()
        for ((f, startUs) in segs) {
            val ex = MediaExtractor().apply { setDataSource(f.path) }
            ex.selectTrack(vidIdx(ex))
            while (true) {
                val n = ex.readSampleData(buf, 0); if (n < 0) break
                bi.set(0, n, ex.sampleTime + startUs, if (ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
                mux.writeSampleData(vTrack, buf, bi); ex.advance()
            }
            ex.release()
        }
        if (aTrack >= 0 && aEx != null) {
            while (true) {
                val n = aEx.readSampleData(buf, 0); if (n < 0 || aEx.sampleTime > endUs) break
                bi.set(0, n, aEx.sampleTime, aEx.sampleFlags)
                mux.writeSampleData(aTrack, buf, bi); aEx.advance()
            }
        }
        aEx?.release(); mux.stop(); mux.release()
        return warn
    }
}
