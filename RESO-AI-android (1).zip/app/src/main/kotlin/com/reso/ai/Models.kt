package com.reso.ai

import android.content.Context
import android.graphics.*
import android.net.Uri
import org.tensorflow.lite.DataType
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.CompatibilityList
import org.tensorflow.lite.gpu.GpuDelegate
import java.io.Closeable
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Models are NOT bundled. The user (or you, in a build step) supplies .tflite files whose licenses allow it. */
object ModelStore {
    enum class Slot(val file: String, val title: String, val scale: Int) {
        GENERAL("superres_general_x4.tflite", "Super-resolution — general / gaming (×4)", 4),
        ANIME("superres_anime_x4.tflite", "Super-resolution — anime (×4)", 4),
        DENOISE("denoise.tflite", "Denoiser (same-size in/out)", 1)
    }
    fun file(c: Context, s: Slot) = File(File(c.filesDir, "models").apply { mkdirs() }, s.file)
    fun installed(c: Context, s: Slot) = file(c, s).exists()

    /** Copies the file in, then loads it once to validate shape/scale. Returns a description or throws. */
    fun import(c: Context, s: Slot, uri: Uri): String {
        val dst = file(c, s)
        val tmp = File(dst.parentFile, s.file + ".tmp")
        c.contentResolver.openInputStream(uri)!!.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
        try { TileModel(tmp, s.scale).close() } catch (e: Throwable) { tmp.delete(); throw e }
        dst.delete(); tmp.renameTo(dst)
        return "Installed ${s.file}"
    }
}

/** Runs a fixed-input-size NHWC float32 image model over overlapping tiles. GPU delegate if supported, else 4-thread CPU. */
class TileModel(file: File, expectedScale: Int) : Closeable {
    private var gpu: GpuDelegate? = null
    private val interp: Interpreter
    val tile: Int
    val scale: Int
    val usesGpu: Boolean
    private val pad = 8

    init {
        val opts = Interpreter.Options()
        try {
            val cl = CompatibilityList()
            if (cl.isDelegateSupportedOnThisDevice) { gpu = GpuDelegate(cl.bestOptionsForThisDevice); opts.addDelegate(gpu) } else opts.setNumThreads(4)
        } catch (_: Throwable) { gpu = null; opts.setNumThreads(4) }
        interp = try { Interpreter(file, opts) } catch (e: Throwable) {
            gpu?.close(); gpu = null; Interpreter(file, Interpreter.Options().setNumThreads(4))
        }
        usesGpu = gpu != null
        val ins = interp.getInputTensor(0); val s = ins.shape()
        require(ins.dataType() == DataType.FLOAT32 && s.size == 4 && s[0] == 1 && s[3] == 3 && s[1] == s[2] && s[1] > 2 * pad) {
            "Model must take float32 input [1,N,N,3] (NHWC, values 0..1). This one: ${s.toList()} ${ins.dataType()}"
        }
        tile = s[1]
        val o = interp.getOutputTensor(0).shape()
        require(o.size == 4 && o[3] == 3 && o[1] % tile == 0 && o[1] == o[2]) { "Unexpected output shape ${o.toList()}" }
        scale = o[1] / tile
        require(scale == expectedScale) { "Expected a ×$expectedScale model, this one is ×$scale" }
    }

    /** Draws model output over [dst] (which should already contain a plain resize) with the given opacity. */
    fun run(src: Bitmap, dst: Bitmap, alpha: Int, check: () -> Unit) {
        val w = src.width; val h = src.height
        val sp = IntArray(w * h); src.getPixels(sp, 0, w, 0, 0, w, h)
        val fx = dst.width.toFloat() / w; val fy = dst.height.toFloat() / h
        val canvas = Canvas(dst)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG).apply { this.alpha = alpha }
        val step = tile - 2 * pad
        val os = tile * scale
        val ins = ByteBuffer.allocateDirect(tile * tile * 3 * 4).order(ByteOrder.nativeOrder())
        val outs = ByteBuffer.allocateDirect(os * os * 3 * 4).order(ByteOrder.nativeOrder())
        val inF = ins.asFloatBuffer(); val outF = outs.asFloatBuffer()
        val buf = FloatArray(os * os * 3)
        val region = IntArray(step * scale * step * scale)
        val off = pad * scale
        fun c(f: Float) = (f * 255f + 0.5f).toInt().coerceIn(0, 255)
        var y = 0
        while (y < h) {
            val ch = minOf(step, h - y)
            var x = 0
            while (x < w) {
                check()
                val cw = minOf(step, w - x)
                inF.rewind()
                for (ty in 0 until tile) {
                    val row = (y - pad + ty).coerceIn(0, h - 1) * w
                    for (tx in 0 until tile) {
                        val p = sp[row + (x - pad + tx).coerceIn(0, w - 1)]
                        inF.put(((p shr 16) and 255) / 255f); inF.put(((p shr 8) and 255) / 255f); inF.put((p and 255) / 255f)
                    }
                }
                ins.rewind(); outs.rewind()
                interp.run(ins, outs)
                outF.rewind(); outF.get(buf)
                val rw = cw * scale; val rh = ch * scale
                for (ry in 0 until rh) {
                    val base = ((ry + off) * os + off) * 3
                    for (rx in 0 until rw) {
                        val i = base + rx * 3
                        region[ry * rw + rx] = (255 shl 24) or (c(buf[i]) shl 16) or (c(buf[i + 1]) shl 8) or c(buf[i + 2])
                    }
                }
                val tb = Bitmap.createBitmap(rw, rh, Bitmap.Config.ARGB_8888)
                tb.setPixels(region, 0, rw, 0, 0, rw, rh)
                // adjacent tiles share exactly the same rounded edge -> no seams
                val dest = Rect(Math.round(x * fx), Math.round(y * fy), Math.round((x + cw) * fx), Math.round((y + ch) * fy))
                canvas.drawBitmap(tb, null, dest, paint)
                tb.recycle()
                x += step
            }
            y += step
        }
    }

    override fun close() { interp.close(); gpu?.close() }
}
