package com.reso.ai

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ContentValues
import android.content.Context
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.SystemClock
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import androidx.work.*
import kotlinx.coroutines.*
import java.io.File
import java.util.concurrent.atomic.AtomicLong

class EnhanceWorker(private val ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result {
        val s = EnhanceSettings.from(inputData)
        val uri = Uri.parse(inputData.getString("uri")!!)
        val workDir = File(ctx.cacheDir, "work-$id").apply { deleteRecursively(); mkdirs() }
        return try { withContext(Dispatchers.Default) { process(s, uri, workDir) } }
        catch (e: CancellationException) { throw e }
        catch (e: Throwable) { Result.failure(workDataOf("error" to (e.message ?: e.javaClass.simpleName))) }
        finally { workDir.deleteRecursively() }
    }

    private suspend fun process(s: EnhanceSettings, uri: Uri, workDir: File): Result = coroutineScope {
        val job = coroutineContext.job
        val check = { job.ensureActive() }
        setForeground(fg("Preparing…", -1f))
        val info = Probe.read(ctx, uri)
        val (ow, oh) = Probe.outputDims(info, s.targetShortSide)
        val mime = Probe.pickMime(ow, oh) ?: error("This device has no hardware video encoder for ${ow}×$oh. Choose a lower resolution.")
        val totalUs = if (s.previewSeconds > 0) minOf(info.durationUs, s.previewSeconds * 1_000_000L) else info.durationUs
        val pts = AtomicLong(0)
        val t0 = SystemClock.elapsedRealtime()

        val ticker = launch(Dispatchers.IO) {
            while (isActive) {
                val f = (pts.get().toFloat() / totalUs).coerceIn(0f, 1f)
                val el = (SystemClock.elapsedRealtime() - t0) / 1000f
                val eta = if (f > 0.01f) (el * (1 - f) / f).toLong() else -1L   // measured, not guessed
                setProgress(workDataOf("p" to f, "eta" to eta))
                setForeground(fg("${(f * 100).toInt()}%", f))
                delay(1000)
            }
        }
        val segs = mutableListOf<Pair<File, Long>>()
        var note = ""
        try {
            FrameEnhancer(ctx, s, info.width, info.height, ow, oh).use { enh ->
                note = enh.describe
                val proc = SegmentProcessor(ctx, info, s, enh, mime)
                var st = 0L
                val segLen = 20_000_000L                      // 20 s chunks
                var n = 0
                while (st < totalUs) {
                    val en = minOf(st + segLen, totalUs)
                    val f = File(workDir, "seg${n++}.mp4")
                    if (proc.run(st, en, f, check) { pts.set(it) }) segs += f to st
                    st = en
                }
            }
        } finally { ticker.cancel() }
        if (segs.isEmpty()) error("No frames could be decoded from this video.")
        setProgress(workDataOf("p" to 1f, "eta" to 0L, "stage" to "Finalizing"))

        val joined = File(workDir, "joined.mp4")
        val warn = Finalizer.concat(ctx, info, segs, joined, totalUs)
        val secs = (SystemClock.elapsedRealtime() - t0) / 1000f
        val outUri: String
        if (s.previewSeconds > 0) {
            val p = File(ctx.cacheDir, "preview.mp4"); joined.copyTo(p, overwrite = true); outUri = Uri.fromFile(p).toString()
        } else outUri = saveToGallery(joined, "RESO_${info.name}_${s.targetShortSide}p.mp4").toString()
        Result.success(workDataOf("out" to outUri, "warn" to (warn ?: ""), "note" to note, "secs" to secs, "clip" to totalUs / 1e6f))
    }

    private fun saveToGallery(f: File, name: String): Uri {
        val r = ctx.contentResolver
        val v = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name); put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/RESO AI"); put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val u = r.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)!!
        r.openOutputStream(u)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
        v.clear(); v.put(MediaStore.Video.Media.IS_PENDING, 0); r.update(u, v, null, null)
        return u
    }

    private fun fg(text: String, p: Float): ForegroundInfo {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("reso", "Processing", NotificationManager.IMPORTANCE_LOW))
        val n = NotificationCompat.Builder(ctx, "reso").setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("RESO AI — enhancing").setContentText(text).setOngoing(true)
            .setProgress(100, (p * 100).toInt().coerceAtLeast(0), p < 0).build()
        return ForegroundInfo(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
    }
}
