# RESO AI — Video Enhancer (Android, Kotlin + Compose)

**Status: first complete draft. Written without an Android SDK in the loop — it has NOT been compiled or run on a device.**
Expect a round of compile fixes and device testing (codec quirks vary a lot between phones).

## Workflow implemented
Import (gallery / file picker) → configure → optional 3-second preview → background processing (WorkManager foreground
service, real progress, measured ETA, cancel) → side-by-side before/after slider → export to `Movies/RESO AI`.

## What is real vs. not
| Feature | Status |
|---|---|
| AI upscaling | **Real, but needs a model you supply** (`.tflite`, float32 NHWC `[1,N,N,3]`, ×4). Tiled inference, GPU delegate if supported, else CPU. No model installed → falls back to conventional bilinear resize and the UI/export note says so. |
| AI denoise | Real if you import a same-size denoiser `.tflite`. Otherwise unavailable (switch disabled). |
| Detail recovery | **Conventional** 3×3 unsharp (capped at 60%), labelled "not AI". "AI strength" blends AI output over a plain resize to keep the original look and reduce artefacts. |
| 60 FPS | **Not AI.** Only 2× frame *blending* (30→60, 24→48). Not motion-compensated → ghosting on fast motion. Real interpolation (RIFE/FILM) is the plan below. |
| 4K | Output is offered only if the device has a hardware encoder for that size. AI at 4K on-device is slow; the preview measures your phone's real speed and extrapolates. No promises made in the UI. |
| Long videos | Source is processed in 20 s segments, frame-streamed (flat memory), segments joined without re-encode, original audio copied. Not yet resumable after a crash. |
| HDR / 10-bit | Rejected with a clear error (no tone-mapping yet). |
| Preview | Two synced ExoPlayers + draggable divider. |

## Models & licences (you must verify each file)
Not bundled. Candidates: Real-ESRGAN / Real-ESRGAN-anime-6B (BSD-3-Clause), RIFE (MIT), FILM (Apache-2.0). You need a TFLite
conversion (e.g. PyTorch → `ai-edge-torch`, or ONNX → TFLite) with fixed input size (128 or 256 recommended; FP16 for GPU delegate).
Check the licence of the *specific weights file* and training data before shipping. Libraries used: TensorFlow Lite (Apache-2.0),
Media3 (Apache-2.0), WorkManager/Compose (Apache-2.0).

## Plan for the missing pieces
1. **Motion-compensated interpolation**: add `Interpolator` interface; RIFE-lite TFLite taking two frames + t → mid frame, run on
   the already-enhanced frames (one AI upscale per source frame). Replace blend in `SegmentProcessor.run`. Handle segment boundaries with 1-frame overlap.
2. **Speed**: replace CPU YUV↔RGB with a GL/AHardwareBuffer path (`SurfaceTexture` in, `EGL + eglPresentationTimeANDROID` out); batch tiles; INT8/FP16 models.
3. **Resume**: persist finished segment files + index, skip them on restart.
4. **ONNX Runtime Mobile** as alternative backend behind the same `TileModel` API (NNAPI/XNNPACK EPs) for models that don't convert to TFLite well.
5. **Optional cloud mode** (`RemoteEnhancer`, not implemented): app uploads 20 s segments (resumable, presigned URLs) → queue (SQS/Redis) →
   GPU workers (PyTorch/TensorRT Real-ESRGAN + RIFE) → output segments downloaded and joined by the existing `Finalizer`.
   Needs: auth, per-minute cost accounting, retention/deletion policy and explicit user consent (video leaves the device), WebSocket/poll status.

## Build
Open in Android Studio (Koala+), JDK 17, sync, run on a physical arm64 device (API 29+). Then Home → AI models → import `.tflite` files.
